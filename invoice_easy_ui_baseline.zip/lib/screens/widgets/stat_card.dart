import 'package:flutter/material.dart';
import 'app_card.dart';

class StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final String? trend;
  const StatCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.trend,
  });
  @override
  Widget build(BuildContext c) {
    final cs = Theme.of(c).colorScheme;
    return AppCard(
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: cs.primaryContainer,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: cs.primary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: Theme.of(
                    c,
                  ).textTheme.bodySmall?.copyWith(color: cs.onSurfaceVariant),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: Theme.of(
                    c,
                  ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                ),
                if (trend != null)
                  Text(
                    trend!,
                    style: Theme.of(
                      c,
                    ).textTheme.labelSmall?.copyWith(color: cs.primary),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
