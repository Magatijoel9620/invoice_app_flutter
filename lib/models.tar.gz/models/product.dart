enum ProductType { product, service }

class ProductItem {
  final String id;
  final String name;
  final ProductType type;
  final double price;
  final String unit;
  final bool taxable;
  final DateTime updatedAt;
  ProductItem({required this.id, required this.name, this.type = ProductType.service, required this.price, this.unit = 'item', this.taxable = false, DateTime? updatedAt}) : updatedAt = updatedAt ?? const DateTime(2000, 1, 1);
  ProductItem copyWith({String? id,String? name,ProductType? type,double? price,String? unit,bool? taxable,DateTime? updatedAt})=>ProductItem(id:id??this.id,name:name??this.name,type:type??this.type,price:price??this.price,unit:unit??this.unit,taxable:taxable??this.taxable,updatedAt:updatedAt??this.updatedAt);
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'type':type.name,'price':price,'unit':unit,'taxable':taxable,'updatedAt':updatedAt.toIso8601String()};
  factory ProductItem.fromJson(Map<String,dynamic> j)=>ProductItem(id:j['id'] as String? ?? '',name:j['name'] as String? ?? '',type:ProductType.values.firstWhere((e)=>e.name==(j['type'] as String? ?? 'service'),orElse:()=>ProductType.service),price:(j['price'] as num?)?.toDouble() ?? 0,unit:j['unit'] as String? ?? 'item',taxable:j['taxable'] as bool? ?? false,updatedAt:DateTime.tryParse(j['updatedAt'] as String? ?? '') ?? const DateTime(2000,1,1));
}
