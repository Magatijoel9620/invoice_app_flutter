class Customer {
  final String id;
  final String name;
  final String phone;
  final String email;
  final String address;
  final String taxId;
  final DateTime updatedAt;
  Customer({required this.id, required this.name, this.phone = '', this.email = '', this.address = '', this.taxId = '', DateTime? updatedAt}) : updatedAt = updatedAt ?? const DateTime(2000, 1, 1);
  Customer copyWith({String? id, String? name, String? phone, String? email, String? address, String? taxId, DateTime? updatedAt}) => Customer(id: id ?? this.id, name: name ?? this.name, phone: phone ?? this.phone, email: email ?? this.email, address: address ?? this.address, taxId: taxId ?? this.taxId, updatedAt: updatedAt ?? this.updatedAt);
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'phone':phone,'email':email,'address':address,'taxId':taxId,'updatedAt':updatedAt.toIso8601String()};
  factory Customer.fromJson(Map<String,dynamic> j)=>Customer(id:j['id'] as String? ?? '',name:j['name'] as String? ?? '',phone:j['phone'] as String? ?? '',email:j['email'] as String? ?? '',address:j['address'] as String? ?? '',taxId:j['taxId'] as String? ?? '',updatedAt:DateTime.tryParse(j['updatedAt'] as String? ?? '') ?? const DateTime(2000,1,1));
}
