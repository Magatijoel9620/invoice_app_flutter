import 'package:uuid/uuid.dart';

enum InvoiceStatus { draft, sent, viewed, partiallyPaid, paid, overdue, cancelled }
enum PaymentMethod { mpesa, bank, cash, card, other }

class InvoiceLine {
  final String id;
  final String description;
  final double quantity;
  final double unitPrice;
  final bool taxable;
  const InvoiceLine({required this.id, required this.description, required this.quantity, required this.unitPrice, this.taxable = false});
  double get total => quantity * unitPrice;
  InvoiceLine copyWith({String? id,String? description,double? quantity,double? unitPrice,bool? taxable})=>InvoiceLine(id:id??this.id,description:description??this.description,quantity:quantity??this.quantity,unitPrice:unitPrice??this.unitPrice,taxable:taxable??this.taxable);
  Map<String,dynamic> toJson()=>{'id':id,'description':description,'quantity':quantity,'unitPrice':unitPrice,'taxable':taxable};
  factory InvoiceLine.fromJson(Map<String,dynamic> j)=>InvoiceLine(id:j['id'] as String? ?? const Uuid().v4(),description:j['description'] as String? ?? '',quantity:(j['quantity'] as num?)?.toDouble() ?? 1,unitPrice:(j['unitPrice'] as num?)?.toDouble() ?? 0,taxable:j['taxable'] as bool? ?? false);
}

class Payment {
  final String id;
  final DateTime date;
  final double amount;
  final PaymentMethod method;
  final String reference;
  final String note;
  const Payment({required this.id,required this.date,required this.amount,required this.method,this.reference='',this.note=''});
  Map<String,dynamic> toJson()=>{'id':id,'date':date.toIso8601String(),'amount':amount,'method':method.name,'reference':reference,'note':note};
  factory Payment.fromJson(Map<String,dynamic> j)=>Payment(id:j['id'] as String? ?? const Uuid().v4(),date:DateTime.tryParse(j['date'] as String? ?? '') ?? DateTime.now(),amount:(j['amount'] as num?)?.toDouble() ?? 0,method:PaymentMethod.values.firstWhere((e)=>e.name==(j['method'] as String? ?? 'other'),orElse:()=>PaymentMethod.other),reference:j['reference'] as String? ?? '',note:j['note'] as String? ?? '');
}

class Invoice {
  final String id;
  final String businessId;
  final String customerId;
  final String customerName;
  final String number;
  final DateTime issueDate;
  final DateTime dueDate;
  final List<InvoiceLine> lines;
  final InvoiceStatus status;
  final double discount;
  final bool vatEnabled;
  final double vatRate;
  final List<Payment> payments;
  final String notes;
  final bool archived;
  final DateTime updatedAt;

  Invoice({required this.id,required this.businessId,required this.customerId,required this.customerName,required this.number,required this.issueDate,required this.dueDate,required this.lines,this.status=InvoiceStatus.draft,this.discount=0,this.vatEnabled=false,this.vatRate=16,this.payments=const [],this.notes='',this.archived=false,DateTime? updatedAt}) : updatedAt = updatedAt ?? const DateTime(2000, 1, 1);
  double get subtotal=>lines.fold(0,(sum,l)=>sum+l.total);
  double get taxableSubtotal=>lines.where((l)=>l.taxable).fold(0,(sum,l)=>sum+l.total);
  double tax(double rate)=>vatEnabled?taxableSubtotal*(rate/100):0;
  double total(double rate)=>subtotal-discount+tax(rate);
  double get amountPaid=>payments.fold(0,(sum,p)=>sum+p.amount);
  double balance(double rate)=>((total(rate)-amountPaid).clamp(0,double.infinity)).toDouble();
  Invoice copyWith({String? id,String? businessId,String? customerId,String? customerName,String? number,DateTime? issueDate,DateTime? dueDate,List<InvoiceLine>? lines,InvoiceStatus? status,double? discount,bool? vatEnabled,double? vatRate,List<Payment>? payments,String? notes,bool? archived,DateTime? updatedAt})=>Invoice(id:id??this.id,businessId:businessId??this.businessId,customerId:customerId??this.customerId,customerName:customerName??this.customerName,number:number??this.number,issueDate:issueDate??this.issueDate,dueDate:dueDate??this.dueDate,lines:lines??this.lines,status:status??this.status,discount:discount??this.discount,vatEnabled:vatEnabled??this.vatEnabled,vatRate:vatRate??this.vatRate,payments:payments??this.payments,notes:notes??this.notes,archived:archived??this.archived,updatedAt:updatedAt??this.updatedAt);
  Map<String,dynamic> toJson()=>{'id':id,'businessId':businessId,'customerId':customerId,'customerName':customerName,'number':number,'issueDate':issueDate.toIso8601String(),'dueDate':dueDate.toIso8601String(),'lines':lines.map((e)=>e.toJson()).toList(),'status':status.name,'discount':discount,'vatEnabled':vatEnabled,'vatRate':vatRate,'payments':payments.map((e)=>e.toJson()).toList(),'notes':notes,'archived':archived,'updatedAt':updatedAt.toIso8601String()};
  factory Invoice.fromJson(Map<String,dynamic> j)=>Invoice(id:j['id'] as String? ?? const Uuid().v4(),businessId:j['businessId'] as String? ?? 'default',customerId:j['customerId'] as String? ?? '',customerName:j['customerName'] as String? ?? 'Customer',number:j['number'] as String? ?? '',issueDate:DateTime.tryParse(j['issueDate'] as String? ?? '') ?? DateTime.now(),dueDate:DateTime.tryParse(j['dueDate'] as String? ?? '') ?? DateTime.now(),lines:(j['lines'] as List? ?? const []).map((e)=>InvoiceLine.fromJson(Map<String,dynamic>.from(e as Map))).toList(),status:InvoiceStatus.values.firstWhere((e)=>e.name==(j['status'] as String? ?? 'draft'),orElse:()=>InvoiceStatus.draft),discount:(j['discount'] as num?)?.toDouble() ?? 0,vatEnabled:j['vatEnabled'] as bool? ?? false,vatRate:(j['vatRate'] as num?)?.toDouble() ?? 16,payments:(j['payments'] as List? ?? const []).map((e)=>Payment.fromJson(Map<String,dynamic>.from(e as Map))).toList(),notes:j['notes'] as String? ?? '',archived:j['archived'] as bool? ?? false,updatedAt:DateTime.tryParse(j['updatedAt'] as String? ?? '') ?? const DateTime(2000,1,1));
}
